<?php

namespace AgenciaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AgenciaBundle extends Bundle
{
}
