<?php

namespace MobilBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class CotizacionController extends Controller
{
    public function informacionProductoAction()
    {
        return $this->render('MobilBundle:Default:index.html.twig');
    }
}
