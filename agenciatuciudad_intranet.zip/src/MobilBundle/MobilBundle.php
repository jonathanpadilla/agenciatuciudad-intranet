<?php

namespace MobilBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MobilBundle extends Bundle
{
}
