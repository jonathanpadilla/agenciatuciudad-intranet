<?php

namespace ProductoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductoBundle extends Bundle
{
}
